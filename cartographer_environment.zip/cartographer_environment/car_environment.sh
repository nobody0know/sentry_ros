sudo apt-get install ninja-build

sudo apt-get install -y google-mock libboost-all-dev  libeigen3-dev libgflags-dev libgoogle-glog-dev liblua5.2-dev libprotobuf-dev  libsuitesparse-dev libwebp-dev ninja-build protobuf-compiler sphinx-common  ros-melodic-tf2-eigen libatlas-base-dev libsuitesparse-dev liblapack-dev
